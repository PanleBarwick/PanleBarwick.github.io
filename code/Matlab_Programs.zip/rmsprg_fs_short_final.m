%{
   January 31/07;  Revised May 21/07; Revised April 19/09; Revised May 6/2011

                  REFINED GENERALIZED MOMENT SELECTION (RGMS) PROCEDURES

      THIS PROGRAM IS CONCERNED WITH TESTS OF MULTIVARIATE ONE-SIDED HYPOTHESES for 
      USE IN TESTS and CONFIDENCE INTERVALS CONCERNING MOMENT INEQUALITIES. 
      
      THIS IS A SHORTENED VERSION OF THE PROGRAM THAT WAS USED TO COMPUTE THE FINITE SAMPLE 
      SIZE AND POWER RESULTS IN ANDREWS AND BARWICK (2012). IT ONLY COMPUTES RESULTS FOR THE
      MMM (I.E., SUM) AND AQLR TEST STATISTICS AND THE PA, t-TEST/KappaAuto/Nm, AND 
      t-TEST/KappaAuto/Bt CRITICAL VALUES. THE RECOMMENDED TEST IN ANDREWS AND JIA (2011) IS 
      THE AQLR/t-TEST/KappaAuto/Bt test. THE MMM/PA TEST IS FASTER TO COMPUTE AND MAY BE USEFUL
      FOR DETERMINING THE ROUGH SHAPE OF A CONFIDENCE INTERVAL BEFORE SWITCHING TO THE 
      RECOMMENDED TEST FOR GETTING MORE PRECISE RESULTS.

      TESTING PROBLEM CONSIDERED HERE:      

                        H_0: MU>=0      VERSUS     H_1: MU NOT >=0,   for   X ~ ( MU, V),

      WHERE THE DISTRIBUTION OF X CAN BE Normal, t5, t3, t2, ChiSq, OR Uniform.

      THE OUTPUT FROM THIS PROGRAM GOES TO THE CURRENT FOLDER.

%}
     
%   ENTER THE NUMBER OF BLOCKS USED IN MONTE CARLO SIMULATION OF CRITICAL VALUES.  
    NUMR1 = 1;   % FOR 40,000 REPS USE 40.  FOR 5,000 REPS USE 5.        

%   SPECIFY THE LENGTH OF BLOCKS USED IN MONTE CARLO SIMULATION OF CRITICAL VALUES.
%   NOTE THAT THE TOTAL NUMBER OF OBSERVATIONS USED TO SIMULATE DATA-DEPENDENT 
%   QUANTILES IS NUMR1 * R1.  
    R1 = 10;   % TYPICALLY THIS IS 1000.  

%   ENTER THE NUMBER OF MONTE CARLO SIMULATIONS OF REJECTION PROBABILITIES for SIZE RESULTS.  
    REPSSIZE = 10;   % TYPICALLY TAKE THIS TO BE THE SAME AS NUMR1*R1.  

%   ENTER THE NUMBER OF MONTE CARLO SIMULATIONS OF REJECTION PROBABILITIES for POWER RESULTS.  
    REPSPOW = 10;   % TYPICALLY TAKE THIS TO BE 40% AS LARGE AS REPSSIZE.  

%{
    NOW LOOP OVER P, N, DISTN, AND V.  

    P IS THE DIMENSION OF THE MULTIVARIATE VECTOR X, WHICH IS THE OBSERVED DATA.
    FOCUS IS ON P = 2, 4, and 10.  
    N IS THE SAMPLE SIZE.  FOCUS IS ON SAMPLE SIZES 100, 250, AND 500.  

    DIST IS THE DISTRIBUTION USED TO SIMULATE THE UNDERLYING RANDOM VARIABLES.
    DIST = 1    DISTRIBUTION IS STD NORMAL.
    DIST = 2    DISTRIBUTION IS t5 (RESCALED TO HAVE VARIANCE ONE)----THICK-TAILED DISTN.
    DIST = 3    DISTRIBUTION IS t3 (RESCALED TO HAVE VARIANCE ONE)----VERY THICK-TAILED DISTN.
    DIST = 4    DISTRIBUTION IS t2----EXTREMELY THICK-TAILED DISTN.
    DIST = 5    DISTRIBUTION IS CHI-SQUARE W/ 3 DF (RECENTERED and RESCALED
                           TO HAVE MEAN 0 and VARIANCE 1)----ASYMMETRIC DISTN.
    DIST = 6    DISTRIBUTION IS UNIFORM (RECENTERED and RESCALED TO HAVE MEAN 0 and 
                            VARIANCE 1)---THIN-TAILED DISTN.  

	THE TYPE OF VARIANCE MATRIX TO BE CONSIDERED IS VTYPE.  
    VTYPE = -1		 V = V_Neg  
    VTYPE = 0		 V = V_Zero = I_p
    VTYPE = 1		 V = V_Pos.  
%}

START = 1;
P = 2;
while P <= 2;
	N = 100;
	while N <= 100;
		DIST = 1;
		while DIST <= 1;
			VTYPE = 0;
			while VTYPE <= 0;

				% THIS PROGRAM COMPUTES (i) SIZE RESULTS, (ii) POWER RESULTS, OR (iii) SIZE AND POWER RESULTS.
				% PROGTYPE = 1     PROGRAM COMPUTES BOTH SIZE AND POWER RESULTS (WITH SIZE-CORRECTION).
				% PROGTYPE = 1.5   PROGRAM COMPUTES ONLY SIZE VALUES.
				% PROGTYPE = 2     PROGRAM COMPUTES ONLY POWER RESULTS.  
				PROGTYPE = 1;

				% ENTER THE DESIRED SIGNIFICANCE LEVEL.  THIS APPLIES TO ALL TESTS CONSIDERED.  
				SIGLEVEL = .05;

				% ENTER THE TESTS THAT ARE TO BE COMPUTED.  TESTSEL IS A VECTOR ONES AND zeros WITH A ONE
				% INDICATING THAT A PARTICULAR TEST IS TO BE COMPUTED.  if TESTSEL[J]=1, THEN TEST J IS 
				% COMPUTED. If TESTSEL[J]=0, TEST J IS NOT COMPUTED.  
				NUMTEST = 100;                  % NUMTEST IS THE MAXIMUM NUMBER OF TESTS THAT ARE BE 
												% COMPUTED.  
				TESTSEL = zeros( NUMTEST, 1);   % TESTSEL DETERMINES WHICH TESTS ARE TO BE CONSIDERED.  
				TESTMAT = zeros( NUMTEST, 6 );  % TESTMAT SPECIFIES THE FEATURES OF THE TESTS.  
								% SEE BELOW for A DESCRIPTION OF HOW DIFFERENT TESTS 
								% ARE DESCRIBED BY THE MATRIX TESTMAT.  
				ETAVEC  = zeros( NUMTEST, 1);  % ETAVEC IS THE VECTOR OF SIZE-CORRECTION CONSTANTS.  
		   
				% THE FOLLOWING LINES OF CODE ARE CHANGED AROUND DEPENDING UPON WHICH TESTS ARE TO BE 
				% CONSIDERED.  
				TESTSEL(1) = 1; TESTMAT( 1, 1:5) = [1,(-10),0,(-10),(-10)];  
				% TEST 1 IS A SUM STAT W/ STD PA CV.   
				TESTSEL(2) = 1; TESTMAT( 2, 1:5) = [2.5,(-10),0,(-10),(-10)];
				% TEST 2 IS THE ADJUSTED QLR STAT WITH PA CRIT VAL.  
				TESTSEL(3) = 1; TESTMAT( 3, 1:5) = [2.5,(-10),11,(.01),0]; 
				% TEST 3 IS THE ADJUSTED QLR STAT WITH t-TEST CV,
				% AUTOMATIC KAPPA & ETA VALUES, BASED ON ASY DISTN.  
				TESTSEL(4) = 1; TESTMAT( 4, 1:5) = [2.5,(-10),1011,(.01),0]; 
				% TEST 4 IS THE ADJUSTED QLR STAT WITH t TEST CV
				% AUTOMATIC KAPPA & ETA VALUES, BASED ON BOOTSTRAP DISTN.
				% THIS IS THE RECOMMENDED TEST.  

				%{
				THE FOLLOWING DESCRIBES THE MATRIX, TESTMAT, THAT DEFINES THE POSSIBLE TESTS 
				THAT CAN BE CONSIDERED. EACH ROW CORRESPONDS TO A DIFFERENT TEST. THE COLUMNS 
				SPECIFY THE PROPERTIES OF THE TEST GIVEN IN THE CORRESPONDING ROW.
				COLUMN 1 DEFINES STATTYPE.
				   STATTYPE==1 for MMM, I.E.SUM, TEST.
				   STATTYPE==2.5 for ADJUSTED QLR TEST. THIS TEST ALWAYS USES A PD WEIGHT MATRIX EVEN if VAR 
								 MATRIX IS SINGULAR. IT ADDS MAX{ .01-DET(OMEGA), 0}*DIAG( V ) TO THE V 
								 MATRIX, WHERE OMEGA IS THE CORRELATION MATRIX THAT CORRESPONDS TO THE V 
								 MATRIX.
				COLUMN 2 IS ARBITRARY.
				COLUMN 3 DEFINES CVTYPE.  
				   CVTYPE==0    for STD PLUG-IN ASYMPTOTIC (PA) CRIT VALUE, 
				   CVTYPE==1    for PHI1, I.E., t TEST, CRIT VALUE BASED ON ADDITIVE SIZE-CORRECTION.
				   CVTYPE==11   for t TEST CRIT VALUE WITH AUTOMATIC DETERMINATION OF KAPPA and
								ETA BASED ON V THROUGH DELTA(OMEGA), WHERE OMEGA IS THE CORR
								MATRIX THAT CORRESPONDS TO V.

				if A BOOTSTRAP RMS CRITICAL VALUE IS DESIRED, ONE ADDS 10 BEFORE THE NUMBER OF THE CVTYPE. 
				THUS,
				   CVTYPE == 100   BOOTSTRAP PLUG-IN ASY CRIT VAL,
				   CVTYPE == 101   BOOTSTRAP PHI1, t TEST, (A CONDITIONAL CV),
				   CVTYPE == 1011  BOOTSTRAP PHI1, t TEST, WITH AUTOMATIC DETERMINATION OF KAPPA 
								   and ETA BASED ON V, 

				COLUMN 4 IS ARBITRARY.
				COLUMN 5 DEFINES KAPPA for CVTYPE 1.
				COLUMN 6 DEFINES THE ADDITIVE CONSTANT ETA THAT IS USED TO ADJUST THE SIZE OF TESTS for 
				  CVTYPE 1. IT IS THE REFINEMENT FACTOR for RGMS CRIT VALUES.  

				ENTER THE COVARIANCE MATRIX, V, OF THE VECTOR X.
				IT IS A P BY P MATRIX.  
				VTYPE = -1		 V = V_Neg  
				VTYPE = 0		 V = V_Zero
				VTYPE = 1		 V = V_Pos.  
				%} 
 
				RHOVEC = zeros( P, 1);
				RHOVEC(1) = 1;     
				if VTYPE==0;
					RHOVEC( 2:P ) = zeros(P-1,1);
				elseif P==2 && VTYPE==-1;
					RHOVEC(2) = -.9;
				elseif P==2 && VTYPE==1;  
					RHOVEC(2) = .5; 
				elseif P==4 && VTYPE==-1;
					RHOVEC(2) = -.9; 
					RHOVEC(3) = .7; 
					RHOVEC(4) = -.5;
				elseif P==4 && VTYPE==1;
					RHOVEC(2) = .9; 
					RHOVEC(3) = .7; 
					RHOVEC(4) = .5;
				elseif P==10 && VTYPE==-1;
					RHOVEC(2) = -.9;         
					RHOVEC(3) = .8; 
					RHOVEC(4) = -.7;
					RHOVEC(5) = .6;
					RHOVEC(6) = -.5;
					RHOVEC(7) = .4;
					RHOVEC(8) = -.3;                
					RHOVEC(9) = .2;
					RHOVEC(10) = -.1;      
				elseif P==10 && VTYPE==1;            
					RHOVEC(2) = .9;             
					RHOVEC(3) = .8;             
					RHOVEC(4) = .7;            
					RHOVEC(5) = .6;            
					RHOVEC(6) = .5;            
					RHOVEC(7) = .5;           
					RHOVEC(8) = .5;              
					RHOVEC(9) = .5;           
					RHOVEC(10) = .5;
				end;     
				if P>1;
					V = toeplitz( RHOVEC );
				else
					V = 1;
				end;
				VINVERSE = pinv( V );
				DIAGV = diag( V );
				STACK = sqrt(diag(V));
				AVGCORR = ( ones( 1,P ) * ( V ./(STACK * STACK') ) * ones( P,1 ) - 1 ) / (P*(P-1)); 
				T0 = tic;

				% WHEN CVTYPE==0, I.E. PA CRIT VAL, FOR SOME TEST THAT IS TO BE COMPUTED, WE CALCULATE THE 
				% NON-DATA-DEPENDENT CRIT VAL HERE. THE SAME CRIT VAL IS USED for SIMULATION REPETITION
				% BECAUSE THE CRIT VAL IS NOT DATA-DEPENDENT.
				if sum( TESTSEL.*(TESTMAT(:,1)==1).*(TESTMAT(:,3)==0 ) ) >= 1;   
				% IF THE MMM/PA TEST IS TO BE COMPUTED, THEN WE COMPUTE THE MMM/PA CRIT VAL.  
					STATTYP = 1; CVTYPE1 = 0; KAPPA1 = 0; ETA1 = 0;
					CVMMMPA = CRITVALS_FS( zeros(P,1), V, zeros(N, P), ETA1, STATTYP, CVTYPE1,... 
					   KAPPA1, SIGLEVEL, R1, NUMR1);
				end;
				if sum( TESTSEL.*(TESTMAT(:,1)==2.5).*(TESTMAT(:,3)==0 ) ) >= 1;  
				% IF THE AQLR/PA TEST IS TO BE COMPUTED, THEN WE COMPUTE THE AQLR/PA CRIT VAL.  
					STATTYP = 2.5; CVTYPE1 = 0; KAPPA1 = 0; ETA1 = 0;
					CVAQLRPA = CRITVALS_FS( zeros(P,1), V, zeros(N, P), ETA1, STATTYP, CVTYPE1,... 
						KAPPA1, SIGLEVEL, R1, NUMR1);
				end;

				% NEXT WE CALCULATE A QUANTITY THAT MEASURES THE RELEVANT AMOUNT OF DEPENDENCE 
				% IN THE V MATRIX.  LET OMEGA DENOTE THE CORRELATION MATRIX THAT CORRESPONDS TO V. 
				% THE QUANTITY DELTA IS THE MINIMUM OVER ALL ELEMENTS OF OMEGA.  
				OMEGA = V ./ (sqrt(diag(V)) * sqrt(diag(V))');
				DELTA = min( OMEGA(:) );
				
% THIS IS THE END OF ALL OF THE INPUTS TO THE PROGRAM.
% NOW START THE PROGRAM.  

				% FIRST WE LOOP OVER THE DIFFERENT PROGTYPES. EITHER WE COMPUTE BOTH ETA VALUES AND
				% POWER (or SIZE) RESULTS, or ONLY ETA VALUES, or ONLY POWER (or SIZE) RESULTS.  
				while PROGTYPE <= 2;
					if PROGTYPE < 2;
						SIMREPS = REPSSIZE;
					elseif PROGTYPE >= 2;
						SIMREPS = REPSPOW;
					end;
					if P==2 && PROGTYPE<2 && VTYPE==-1;
						fid=fopen('.\SIZ_Neg2.txt', 'a+'); 
					elseif P==2 && PROGTYPE<2 && VTYPE==0;
						fid=fopen('.\SIZ_Zer2.txt', 'a+'); 
					elseif P==2 && PROGTYPE<2 && VTYPE==1;
						fid=fopen('.\SIZ_Pos2.txt', 'a+'); 
					elseif P==2 && PROGTYPE==2 && VTYPE==-1;
						fid=fopen('.\POW_Neg2.txt', 'a+'); 
					elseif P==2 && PROGTYPE==2 && VTYPE==0;
						fid=fopen('.\POW_Zer2.txt', 'a+'); 
					elseif P==2 && PROGTYPE==2 && VTYPE==1;
						fid=fopen('.\POW_Pos2.txt', 'a+'); 
					elseif P==4 && PROGTYPE<2 && VTYPE==-1;
						fid=fopen('.\SIZ_Neg4.txt', 'a+'); 
					elseif P==4 && PROGTYPE<2 && VTYPE==0;
						fid=fopen('.\SIZ_Zer4.txt', 'a+'); 
					elseif P==4 && PROGTYPE<2 && VTYPE==1;
						fid=fopen('.\SIZ_Pos4.txt', 'a+'); 
					elseif P==4 && PROGTYPE==2 && VTYPE==-1;
						fid=fopen('.\POW_Neg4.txt', 'a+'); 
					elseif P==4 && PROGTYPE==2 && VTYPE==0;
						fid=fopen('.\POW_Zer4.txt', 'a+'); 
					elseif P==4 && PROGTYPE==2 && VTYPE==1;
						fid=fopen('.\POW_Pos4.txt', 'a+'); 
					elseif P==10 && PROGTYPE<2 && VTYPE==-1;
						fid=fopen('.\SIZ_Neg10.txt', 'a+'); 
					elseif P==10 && PROGTYPE<2 && VTYPE==0;
						fid=fopen('.\SIZ_Zer10.txt', 'a+'); 
					elseif P==10 && PROGTYPE<2 && VTYPE==1;
						fid=fopen('.\SIZ_Pos10.txt', 'a+'); 
					elseif P==10 && PROGTYPE==2 && VTYPE==-1;
						fid=fopen('.\POW_Neg10.txt', 'a+'); 
					elseif P==10 && PROGTYPE==2 && VTYPE==0;
						fid=fopen('.\POW_Zer10.txt', 'a+'); 
					elseif P==10 && PROGTYPE==2 && VTYPE==1;
						fid=fopen('.\POW_Pos10.txt', 'a+'); 
					end;
					
					% NOW COMPUTE ALL OF THE 2^P-1 MU VECTORS CONSISTING OF 0'S && INFINITIES THAT ARE 
					% USED FOR SIZE CALCULATIONS.  
					ETAMAT = zeros( NUMTEST, 2^P-1 );
					FGRIDVEC=[0;25];    % HERE 25 PLAYS THE ROLE OF INFINITY. 
					INDLAG = ones(1,P); % INDLAG IS A P ROW VECTOR WHOSE ELEMENTS INDEX WHICH ELEMENTS
										% FROM FGRIDVEC ARE TO ENTER THE J-TH ROW OF MU, WHICH IS THE J-TH MEAN VECTOR. 
					INDLAG(P) = 0; 		% SET THE LAST ELEMENT OF INDLAG EQUAL TO ZERO, SO THAT WHEN IT IS
										% INCREASED BY ONE BELOW WE GET A VECTOR OF ONES AS THE FIRST INDLAG VECTOR.  
					MAXIND = 2; 		% MAXIND IS THE MAXIMUM VALUE THAT ANY OF THE ELEMENTS IN INDLAG
										% CAN TAKE ON. BY DEFINITION, IT EQUALS THE NUMBER OF ELEMENTS IN FGRIDVEC, 
										% I.E., NUMGRD. 
					MU = zeros(2^P-1,P); % MU1 IS THE FIRST PART OF THE MU MATRIX.  
					J = 1;
					while J <= 2^P-1;
						L = P; 
						while L >= 1;
							if INDLAG(L) < MAXIND;
								INDLAG(L) = INDLAG(L)+1;
								if L<P;
									INDLAG(L+1:P) = ones(1,P-L);
								end;
								if min(INDLAG)==1;  
								%  IF AT LEAST ONE ELEMENT OF INDLAG EQUALS ZERO THEN THE CORRESPONDING
								%  MU VECTOR IS ON THE BOUNDARY OF THE NULL && WE INCLUDE THIS MU 
								%  VECTOR IN THE MATRIX OF MU VECTORS.  
									MU(J,:) = FGRIDVEC(INDLAG)';  % J-TH ROW OF MU TAKES THE VALUES FROM FGRIDVEC
																  % THAT CORRESPOND TO THE INDICES IN INDLAG. 
								else
									J = J-1;
									break; 
								end;
								break;
							end;
							L = L-1;
						end;
						J = J+1;
					end;

					% NOW WE SPECIFY THE MATRIX MU OF MEAN VECTORS OF THE MULTIVARIATE NORMAL VECTOR X 
					% THAT ARE USED WHEN PROGTYPE = 2, I.E., WHEN THE PROGRAM COMPUTES POWER.   
					% EACH ROW IS A P BY 1 VECTOR.  

					% P = 2 MU VALUES FOR POWER CALCULATIONS.  
					if P==2 && PROGTYPE==2;
					% MU VALUE CHOSEN SO THAT POW ENVELOPE = .7500   BASED ON (40000, 40000) REPS.      
						MU = zeros( 7, P );   
						MU( 1, : ) = 0 * ones( 1, P);   MU( 1, 1) = -2.309;
						MU( 2, : ) = 1 * ones( 1, P);   MU( 2, 1) = -2.309;     
						MU( 3, : ) = 2 * ones( 1, P);   MU( 3, 1) = -2.309;      
						MU( 4, : ) = 3 * ones( 1, P);   MU( 4, 1) = -2.309;      
						MU( 5, : ) = 4 * ones( 1, P);   MU( 5, 1) = -2.309;     
						MU( 6, : ) = 7 * ones( 1, P);   MU( 6, 1) = -2.309;     
						MU( 7, 1 ) = -sqrt(2.30*2.30/2);   MU( 7, 2) = -sqrt(2.30*2.30/2);           
						if VTYPE== -1 || VTYPE==2;  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(1, 1) = .43365* MU(1, 1);                  
							MU(2, 1) = .7814 * MU(2, 1);                
							MU(3, 1) = .9975 * MU(3, 1);                
							MU(4, 1) = 1.0   * MU(4, 1);                
							MU(5, 1) = 1.0   * MU(5, 1);                
							MU(6, 1) = 1.0   * MU(6, 1);                
							MU(7, :) = .31762 * MU(7, :);                     
							% RESCALE OF ROW 7 OF MU SO THAT POWER ENVELOPE = .7500                   
							% for EACH ROW BASED ON (40000, 40000) REPS.            
						elseif VTYPE==1 || VTYPE==3;  % RESCALE OF ROW BASED ON (40000, 40000) REPS.                  
							MU(1:6, 1) = 1.0 * MU(1:6, 1);                  
							MU(7, :) = 1.2323 * MU(7, :);                     
							% RESCALE OF ROW 7 OF MU SO THAT POWER ENVELOPE = .7500                    
							% for EACH ROW BASED ON (40000, 40000) REPS.       
						end;
					end;
					% RESCALE OF MU VECTORS FOR P=2 ARE COMPLETE.  
					
					% P = 4 MU VALUES FOR POWER CALCULATIONS.  
					if P==4 && PROGTYPE==2;     
						MU = zeros( 24, P );     
						MU( 1, : ) = ones( 1, P);       MU( 1, 1) = -sqrt(2.459*2.459/2);   MU( 1, 2) = -sqrt(2.459*2.459/2);   % THIS ONE IS CORRECTED.  
						MU( 2, : ) = 2 * ones( 1, P);   MU( 2, 1) = -sqrt(2.459*2.459/2);   MU( 2, 2) = -sqrt(2.459*2.459/2);   % (40000, 40000) REPS.      
						MU( 3, : ) = 3 * ones( 1, P);   MU( 3, 1) = -sqrt(2.459*2.459/2);   MU( 3, 2) = -sqrt(2.459*2.459/2);   % THIS ONE IS CORRECTED.      
						MU( 4, : ) = 4 * ones( 1, P);   MU( 4, 1) = -sqrt(2.459*2.459/2);   MU( 4, 2) = -sqrt(2.459*2.459/2);   % THIS ONE IS CORRECTED.      
						MU( 5, : ) = 7 * ones( 1, P);   MU( 5, 1) = -sqrt(2.459*2.459/2);   MU( 5, 2) = -sqrt(2.459*2.459/2);   % THIS ONE IS CORRECTED.      
						
						MU( 6, : ) = 7*ones( 1, P);   MU( 6, 3 ) = 1;   MU( 6, 1) = -sqrt(2.459*2.459/2);   MU( 6, 2) = -sqrt(2.459*2.459/2); % THIS ONE IS CORRECTED. 
						MU( 7, : ) = 7*ones( 1, P);   MU( 7, 3 ) = 2;   MU( 7, 1) = -sqrt(2.459*2.459/2);   MU( 7, 2) = -sqrt(2.459*2.459/2); % THIS ONE IS CORRECTED.      
						MU( 8, : ) = 7*ones( 1, P);   MU( 8, 3 ) = 3;   MU( 8, 1) = -sqrt(2.459*2.459/2);   MU( 8, 2) = -sqrt(2.459*2.459/2); % THIS ONE IS CORRECTED. 
						MU( 9, : ) = 7*ones( 1, P);   MU( 9, 3 ) = 4;   MU( 9, 1) = -sqrt(2.459*2.459/2);   MU( 9, 2) = -sqrt(2.459*2.459/2); % THIS ONE IS CORRECTED. 
						
						MU( 10, : ) = 1 * ones( 1, P);   MU( 10, 1) = -2.4705;   % THIS ONE IS CORRECTED. 
						MU( 11, : ) = 2 * ones( 1, P);   MU( 11, 1) = -2.4705;   % THIS ONE IS CORRECTED. 
						MU( 12, : ) = 3 * ones( 1, P);   MU( 12, 1) = -2.4705;   % THIS ONE IS CORRECTED. 
						MU( 13, : ) = 4 * ones( 1, P);   MU( 13, 1) = -2.4705;   % THIS ONE IS CORRECTED. 
						MU( 14, : ) = 7 * ones( 1, P);   MU( 14, 1) = -2.4705;    % THIS ONE IS CORRECTED.
						
						MU( 15, : ) = 7*ones( 1, P);   MU( 15, 2:3 ) = ones( 1, 2);     MU( 15, 1) = -2.4705;  % THIS ONE IS CORRECTED. 
						MU( 16, : ) = 7*ones( 1, P);   MU( 16, 2:3 ) = 2*ones( 1, 2);  MU( 16, 1) = -2.4705;   % THIS ONE IS CORRECTED. 
						MU( 17, : ) = 7*ones( 1, P);   MU( 17, 2:3 ) = 3*ones( 1, 2);  MU( 17, 1) = -2.4705;   % THIS ONE IS CORRECTED. 
						MU( 18, : ) = 7*ones( 1, P);   MU( 18, 2:3 ) = 4*ones( 1, 2);  MU( 18, 1) = -2.4705;   % THIS ONE IS CORRECTED.
						
						MU( 19, : ) = zeros( 1, P);   MU( 19, 1 ) = -sqrt(2.459*2.459/2);     MU( 19, 2 ) = -sqrt(2.459*2.459/2); % THIS ONE IS CORRECTED. 
						MU( 20, : ) = zeros( 1, P);   MU( 20, 1 ) = -2.4705;  % THIS ONE IS CORRECTED. 
						
						BSIZE = 25;
						MU( 21, : ) = BSIZE * ones( 1, P);  MU( 21, 1)   = -2.4705; % THIS ONE IS CORRECTED. 
						MU( 22, : ) = BSIZE * ones( 1, P);  MU( 22, 1:2) = -sqrt(2.459*2.459/2) * ones( 1, 2);   % THIS ONE IS CORRECTED. 
						MU( 23, : ) = BSIZE * ones( 1, P);  MU( 23, 1:3) = -sqrt( 2.4668*2.4668/3 ) * ones( 1, 3);   % THIS ONE IS CORRECTED. 
						MU( 24, : ) = BSIZE * ones( 1, P);  MU( 24, 1:4) = -sqrt( 2.470*2.470/4 ) * ones( 1, 4 ); % THIS ONE IS CORRECTED. 
						
						if (VTYPE== -1) || (VTYPE==2);
							MU(1, 1:2)  =       .3166* MU(1, 1:2);  % RESCALE BASED ON (40000, 40000) REPS.                 
							MU(2:5, 1:2)=       .3178* MU(2:5, 1:2);% RESCALE BASED ON (40000, 40000) REPS.  
							MU(6, 1:2)  =       .3166* MU(6, 1:2);  % RESCALE BASED ON (40000, 40000) REPS.         
							MU(7:9, 1:2)=       .3178* MU(7:9, 1:2);% RESCALE BASED ON (40000, 40000) REPS.         
							MU(10, 1)   =      .76155* MU(10, 1);   % RESCALE BASED ON (40000, 40000) REPS.    
							MU(11, 1)   =       .9829* MU(11, 1);   % RESCALE BASED ON (40000, 40000) REPS.     
							MU(12:14, 1)=         1.0* MU(12:14, 1);% RESCALE BASED ON (40000, 40000) REPS.    
							MU(15, 1)   =      .76155* MU(15, 1);   % RESCALE BASED ON (40000, 40000) REPS.     
							MU(16, 1)   =       .9829* MU(16, 1);   % RESCALE BASED ON (40000, 40000) REPS.                    
							MU(17:18, 1)=         1.0* MU(17:18, 1);% RESCALE BASED ON (40000, 40000) REPS.                    
							MU(19, 1:2) =     .182635* MU(19, 1:2); % RESCALE BASED ON (40000, 40000) REPS.                 
							MU(20, 1)   =      .34908* MU(20, 1);   % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(21, 1)   =         1.0* MU(21, 1);   % RESCALE BASED ON (40000, 40000) REPS.                 
							MU(22, 1:2) =       .3178* MU(22, 1:2); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(23, 1:3) =      .18303* MU(23, 1:3); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(24, 1:4) =      .14218* MU(24, 1:4); % RESCALE BASED ON (40000, 40000) REPS.            
						elseif (VTYPE==1) || (VTYPE==3);               
							MU(1:9, 1:2)=   1.383 * MU(1:9, 1:2);% RESCALE BASED ON (40000, 40000) REPS.                 
							MU(19, 1:2) =   1.383 * MU(19, 1:2); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(22, 1:2) =   1.383 * MU(22, 1:2); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(23, 1:3) =   1.5888* MU(23, 1:3); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(24, 1:4) =   1.7241* MU(24, 1:4); % RESCALE BASED ON (40000, 40000) REPS.       
						end;   
					end;
					% RESCALE OF MU VECTORS FOR P=4 ARE COMPLETE.  
					
					% P >= 10 MU VALUES FOR POWER CALCULATIONS. 
					if P>=10 && PROGTYPE==2;     
						MU = zeros( 40, P );     
						MU( 1, : ) = ones( 1, P);       MU( 1, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.     
						MU( 2, : ) = 2 * ones( 1, P);   MU( 2, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.     
						MU( 3, : ) = 3 * ones( 1, P);   MU( 3, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.     
						MU( 4, : ) = 4 * ones( 1, P);   MU( 4, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.     
						MU( 5, : ) = 7 * ones( 1, P);   MU( 5, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED. 
						
						MU( 6, : ) = 7*ones( 1, P);   MU( 6, 3:5 ) = ones( 1, 3);     MU( 6, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.     
						MU( 7, : ) = 7*ones( 1, P);   MU( 7, 3:5 ) = 2*ones( 1, 3);   MU( 7, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.      
						MU( 8, : ) = 7*ones( 1, P);   MU( 8, 3:5 ) = 3*ones( 1, 3);   MU( 8, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.      
						MU( 9, : ) = 7*ones( 1, P);   MU( 9, 3:5 ) = 4*ones( 1, 3);   MU( 9, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.       
						
						MU( 10, : ) = ones( 1, P);         MU( 10, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4); % THIS ONE IS CORRECTED.       
						MU( 11, : ) = 2 * ones( 1, P);    MU( 11, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.       
						MU( 12, : ) = 3 * ones( 1, P);    MU( 12, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.       
						MU( 13, : ) = 4 * ones( 1, P);    MU( 13, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.       
						MU( 14, : ) = 7 *ones( 1, P);     MU( 14, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.       
						
						MU( 15, : ) = 7*ones( 1, P);   MU( 15, 5:7 ) = ones( 1, 3);                          
									MU( 15, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.       
						MU( 16, : ) = 7*ones( 1, P);   MU( 16, 5:7 ) = 2* ones( 1, 3);                      
									MU( 16, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.       
						MU( 17, : ) = 7*ones( 1, P);   MU( 17, 5:7 ) = 3* ones( 1, 3);                   
									MU( 17, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.      
						MU( 18, : ) = 7*ones( 1, P);   MU( 18, 5:7 ) = 4* ones( 1, 3);                    
									MU( 18, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.       
						
						MU( 19, : ) = 1 * ones( 1, P);   MU( 19, 1) = -2.6817;   % THIS ONE IS CORRECTED.      
						MU( 20, : ) = 2 * ones( 1, P);   MU( 20, 1) = -2.6817;   % THIS ONE IS CORRECTED.      
						MU( 21, : ) = 3 * ones( 1, P);   MU( 21, 1) = -2.6817;   % THIS ONE IS CORRECTED.      
						MU( 22, : ) = 4 * ones( 1, P);   MU( 22, 1) = -2.6817;   % THIS ONE IS CORRECTED.      
						MU( 23, : ) = 7 * ones( 1, P);   MU( 23, 1) = -2.6817;   % THIS ONE IS CORRECTED.      
						
						MU( 24, : ) = 7*ones( 1, P);   MU( 24, 2:4 ) = ones( 1, 3);      MU( 24, 1) = -2.6817;  % THIS ONE IS CORRECTED.      
						MU( 25, : ) = 7*ones( 1, P);   MU( 25, 2:4 ) = 2*ones( 1, 3);  MU( 25, 1) = -2.6817;  % THIS ONE IS CORRECTED.      
						MU( 26, : ) = 7*ones( 1, P);   MU( 26, 2:4 ) = 3*ones( 1, 3);  MU( 26, 1) = -2.6817;  % THIS ONE IS CORRECTED.      
						MU( 27, : ) = 7*ones( 1, P);   MU( 27, 2:4 ) = 4*ones( 1, 3);  MU( 27, 1) = -2.6817;  % THIS ONE IS CORRECTED.      
						
						MU( 28, : ) = zeros( 1, P);   MU( 28, 1:2 ) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.       
						MU( 29, : ) = zeros( 1, P);   MU( 29, 1:4 ) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.      
						MU( 30, : ) = zeros( 1, P);   MU( 30, 1 ) = -2.6817;  % THIS ONE IS CORRECTED.      
						
						BSIZE = 25;     
						MU( 31, : ) = BSIZE * ones( 1, P);     MU( 31, 1) = -2.6817;  % THIS ONE IS CORRECTED.      
						MU( 32, : ) = BSIZE * ones( 1, P);     MU( 32, 1:2) = -sqrt(2.6767*2.6767/2)*ones(1,2);  % THIS ONE IS CORRECTED.       
						MU( 33, : ) = BSIZE * ones( 1, P);     MU( 33, 1:3) = -sqrt( 2.6782*2.6782/3 ) * ones( 1, 3);  % THIS ONE IS CORRECTED.      
						MU( 34, : ) = BSIZE * ones( 1, P);     MU( 34, 1:4) = -sqrt(2.672*2.672/4)*ones(1,4);  % THIS ONE IS CORRECTED.      
						
						MU( 35, : ) = BSIZE * ones( 1, P);     MU( 35, 1:5) = -sqrt( 2.675*2.675/5 ) * ones( 1, 5);  % THIS ONE IS CORRECTED.      
						MU( 36, : ) = BSIZE * ones( 1, P);     MU( 36, 1:6) = -sqrt( 2.6683*2.6683/6 ) * ones( 1, 6);  % THIS ONE IS CORRECTED.      
						MU( 37, : ) = BSIZE * ones( 1, P);     MU( 37, 1:7) = -sqrt( 2.672*2.672/7 ) * ones( 1, 7);   % THIS ONE IS CORRECTED.      
						MU( 38, : ) = BSIZE * ones( 1, P);     MU( 38, 1:8) = -sqrt( 2.6772*2.6772/8 ) * ones( 1, 8);  % THIS ONE IS CORRECTED.     
						MU( 39, : ) = BSIZE * ones( 1, P);     MU( 39, 1:9) = -sqrt( 2.6645*2.6645/9 ) * ones( 1, 9);  % THIS ONE IS CORRECTED.     
						MU( 40, : ) = -sqrt( 2.6690*2.6690/10 ) * ones( 1, P);  % THIS ONE IS CORRECTED.      
						
						if (VTYPE== -1) || (VTYPE==2);               
							MU(1:9, 1:2) =  .31785 * MU(1:9, 1:2);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(10:18, 1:4) =  .26011 * MU(10:18, 1:4); % RESCALE BASED ON (40000, 40000) REPS.                
							MU(19, 1) =  .7401 * MU(19, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(20, 1) =  .9634 * MU(20, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(21:23, 1) =  1.0 * MU(21:23, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(24, 1) =  .7401 * MU(24, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(25, 1) =  .9634 * MU(25, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(26:27, 1) =  1.0 * MU(26:27, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(28, 1:2) =  .2822 * MU(28, 1:2);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(29, 1:4) =  .24867 * MU(29, 1:4); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(30, 1) =   .43075 * MU(30, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(31, 1) =  1.0 * MU(31, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(32, 1:2) =  .31785 * MU(32, 1:2);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(33, 1:3) =   .27130 * MU(33, 1:3); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(34, 1:4) =   .26011 * MU(34, 1:4); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(35, 1:5) =   .2495 * MU(35, 1:5);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(36, 1:6) =   .2455 * MU(36, 1:6);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(37, 1:7) =   .2406 * MU(37, 1:7);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(38, 1:8) =   .23815 * MU(38, 1:8); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(39, 1:9) =   .23709 * MU(39, 1:9); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(40, 1:10) = .2361 * MU(40, 1:10);  % RESCALE BASED ON (40000, 40000) REPS.            
						elseif (VTYPE==1) || (VTYPE==3);                
							MU(1:9, 1:2) =  1.3857* MU(1:9, 1:2);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(10:18, 1:4) =  1.847* MU(10:18, 1:4);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(19:27, 1) =  1.0* MU(19:27, 1);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(28, 1:2) =  1.3857* MU(28, 1:2); % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(29, 1:4) =  1.847* MU(29, 1:4);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(30, 1) =  1.0* MU(30, 1);  % RESCALE BASED ON (40000, 40000) REPS.                      
							MU(31, 1) =  1.0* MU(31, 1);  % RESCALE BASED ON (40000, 40000) REPS.                      
							MU(32, 1:2) =  1.3857* MU(32, 1:2);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(33, 1:3) =  1.6427* MU(33, 1:3);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(34, 1:4) =  1.847* MU(34, 1:4);   % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(35, 1:5) =  2.0066* MU(35, 1:5);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(36, 1:6) =  2.1243* MU(36, 1:6);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(37, 1:7) =  2.2622* MU(37, 1:7);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(38, 1:8) =  2.3840* MU(38, 1:8);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(39, 1:9) =  2.5155* MU(39, 1:9);  % RESCALE BASED ON (40000, 40000) REPS.                  
							MU(40, 1:10) =  2.6145* MU(40, 1:10);  % RESCALE BASED ON (40000, 40000) REPS.  
						end;
					end;
					% RESCALE OF MU VECTORS FOR P=10 ARE COMPLETE.  
					
					REJMAT = zeros( NUMTEST, size(MU,1) );     
					AVGQUANT = zeros( NUMTEST, size(MU,1) );     
					SDQUANT = zeros( NUMTEST, size(MU,1) );     
					STATCORR = zeros( NUMTEST, size(MU,1) );     
					CVCORR = zeros( NUMTEST, size(MU,1) );     
					MUNULL = zeros( size(MU) );

					% LOOP OVER THE DIFFERENT MEAN VECTORS BEING CONSIDERED.  
					JMU = 1;     
					while JMU <= size(MU,1);            
						% LOOP OVER THE DIFFERENT TESTS BEING CONSIDERED.  
						STATPREV = zeros( SIMREPS, 1);          
						CVPREV = zeros( SIMREPS, 1);         
						JTEST = 1;         
						while JTEST <= NUMTEST;             
							SKIP = 0;
						
							% DO NOT COMPUTE THE TEST IF TESTSEL(JTEST) = 0.  
							if TESTSEL(JTEST)==0;                 
								SKIP = 1;            
							end;            
							if SKIP==0;
								STATLONG = zeros( SIMREPS, 1);            
								CVLONG   = zeros( SIMREPS, 1);            
								STATTYPE = TESTMAT( JTEST, 1);            
								NUMMAX   = TESTMAT( JTEST, 2);            
								CVTYPE   = TESTMAT( JTEST, 3);            
								KAPPA    = TESTMAT( JTEST, 5);          
								ETA      = ETAVEC( JTEST ); 

								% COMPUTE THE NON-DATA-DEPENDENT CRITICAL VALUES FOR THE CASE OF CVTYPE = 0.
								% IN THIS CASE, THE SAME CRITICAL VALUE IS USED for EVERY SIMULATION REPETITION.  
								if CVTYPE == 0 && STATTYPE==1;                  
									CVLONG = ones( SIMREPS, 1) * CVMMMPA;            
								elseif CVTYPE == 0 && STATTYPE==2.5;                  
									CVLONG = ones( SIMREPS, 1) * CVAQLRPA;            
								end;

								% THIS IS SEED FOR FINITE SAMPLE RESULTS.  
								SEED = 9872001;
								STREAM = RandStream.create('mt19937ar','seed',SEED);
								s = RandStream.setDefaultStream(STREAM);                               
								
								VSQRT = sqrtm(V);	% V CANT BE SINGULAR

								% LOOP OVER THE DIFFERENT SIMULATION REPETITIONS, THE NUMBER OF WHICH IS SIMREPS,
								% WHICH ARE USED IN THE REJECTION PROBABILITY CALCULATIONS.             
								JR2 = 1;            
								while JR2 <= SIMREPS;

								% SIMULATE AN N BY P MATRIX EACH ROW OF WHICH IS V^(1/2) * X_i, WHERE X_i IS AN IID P 
								% VECTOR WITH EACH ELEMENT HAVING DISTRIBUTION EQUAL TO  "DIST" and DIST = NORMAL,
								% DIST = t5, DIST = t3, DIST = t2, DIST = Chi-Square w/ 3 df, or DIST = Uniform.                         
								% THESE RV'S ARE USED TO MAKE THE REJECTION PROBABILITY CALCULATIONS. 
									XMAT = zeros( N, P ) ;               
									if DIST == 1;   		% DIST = 1 IS A STD NORMAL DISTN.                                            
										XMAT = randn( N, P)*VSQRT + ones( N, 1)*MU( JMU, : )/sqrt(N);               
									elseif DIST == 2 || DIST == 3;                     
										if DIST == 2;  		% DIST = 2 IS A t DISTN WITH 5 DF (RESCALED TO HAVE VARIANCE 1).                             
											DF = 5;                        
										elseif DIST == 3;	% DIST = 3 IS A t DISTN WITH 3 DF (RESCALED TO HAVE VARIANCE 1).                                                  
											DF = 3;  
										end;                     
										A = 1;                     
										while A <= P;                           
											CHI = randn( N, DF);                           
											XMAT( :, A) = sqrt( abs((DF-2)/DF) ) * randn( N, 1)...                                         
											./ sqrt( sum( (CHI.*CHI),2 ) /DF );                           
											A = A + 1;                     
										end;                        
										XMAT = XMAT*VSQRT + ones( N, 1)*MU( JMU, : )/sqrt(N);                  
									elseif DIST == 4;  		% DIST = 4 IS A t DISTN WITH 2 DF.                       
										A = 1;                     
										while A <= P;                        
											CHI = randn( N, 2);                        
											XMAT( :, A) = randn( N, 1) ./ sqrt( sum( (CHI.*CHI),2 ) /2 );                        
											A = A + 1;                     
										end;                     
										XMAT = XMAT*VSQRT + ones( N, 1)*MU( JMU, : )/sqrt(N);                     
									elseif DIST == 5;  		% DIST = 5 IS A CHI-SQUARE W/ 3 DF DISTN (RECENTERED AND 
															% RESCALED TO HAVE MEAN 0 && VARIANCE 1).                        
										ZMAT1 = randn( N, P);                     
										ZMAT2 = randn( N, P);                     
										ZMAT3 = randn( N, P);                     
										XMAT =  ( (ZMAT1.*ZMAT1 + ZMAT2.*ZMAT2 + ZMAT3.*ZMAT3 - 3)/sqrt( 6 ) )...                             
										*VSQRT + ones( N, 1)*MU( JMU, : )/sqrt(N);                  
									elseif DIST == 6;  		% DIST = 6 IS A UNIFORM DISTN (RECENTERED AND RESCALED
															% TO HAVE MEAN 0 && VARIANCE 1).                
										XMAT = ( sqrt(12) * ( rand( N, P) - .5 ) )*VSQRT... 
										+ ones( N, 1)*MU( JMU, : )/sqrt(N);               
									end;               
									XBAR = sqrt( N ) * mean( XMAT );  %  XBAR IS A 1 BY P VECTOR.                
									VHAT = cov( XMAT );
									
									% COMPUTE THE VALUE OF THE TEST STATISTIC FOR THE JR2-TH SIMULATED SAMPLE.                 
									STATLONG( JR2 ) = STAT( XBAR, VHAT, STATTYPE );
									
									% COMPUTE THE DATA-DEPENDENT CRITICAL VALUES FOR THE CASES WHERE CVTYPE DOES
									% NOT EQUAL 0 || -1.  
									if (CVTYPE >= 1);
										CVLONG( JR2 ) = CRITVALS_FS( XBAR', VHAT, XMAT, ETA, STATTYPE, CVTYPE,...
											KAPPA, SIGLEVEL, R1, NUMR1);                
									end;
									JR2 = JR2 + 1;            
								end;
								% END THE LOOP OVER THE SIMREPS SIMULATIONS.                 
								
								% WHEN PROGTYPE < 2, COMPUTE THE ETA VALUE CORRESPONDING TO THE CURRENT MU VECTOR.  
								if PROGTYPE<2;               
									DIFFVEC = STATLONG - CVLONG;               
									DIFFVEC = sort( DIFFVEC );               
									ETAMAT( JTEST, JMU ) = DIFFVEC( ceil( (1-SIGLEVEL)*size(DIFFVEC,1) ) );             
								end;
								
								% COMPUTE THE REJECTION PROBABILITY, AVERAGE VALUE OF THE QUANTILES, AND STD
								% DEVIATION OF THE QUANTILES. THESE ARE SCALAR QUANTITIES.              
								REJMAT( JTEST, JMU )   = mean( ( STATLONG > CVLONG) );
								AVGQUANT( JTEST, JMU ) = mean( CVLONG ); 
								SDQUANT( JTEST, JMU )  = std( CVLONG );
							end;            
							JTEST = JTEST + 1;         
						end;
						% END OF LOOP FOR SPECIFIC TESTTYPE.              
						
						JMU = JMU + 1;     
					end;
					% END OF LOOP FOR SPECIFIC MU VALUE.  
					
					% WHEN PROGTYPE < 2, COMPUTE THE MAXIMUM ETA VALUE OVER ALL THE DIFFERENT MU
					% VECTORS CONSIDERED.       
					if PROGTYPE<2;        
						ETAVEC = max( ETAMAT,[],2 );     
					end;    
										 
					% PRINT RESULTS.  
					DATE1=date; 
					fprintf(fid,'*************************************************************************\r\n');
					fprintf(fid,'*************************************************************************\r\n');
					fprintf(fid,DATE1);
					fprintf(fid,'\r\n');
					fprintf(fid,'THIS IS OUTPUT FROM PROGRAM: rmsprg_fs_short_final.\r\n');
					fprintf(fid,'\r\n');
					if PROGTYPE < 2;
						fprintf(fid,'            FINITE-SAMPLE SIZE RESULTS \r\n');
					elseif PROGTYPE >= 2;
						fprintf(fid,'            FINITE-SAMPLE POWER RESULTS \r\n');
					end;
					fprintf(fid,'\r\n');
					fprintf(fid,'            FOR MULTIVARIATE ONE-SIDED TESTS \r\n');
					fprintf(fid,'            FOR MOMENT INEQUALITY PROBLEMS  \r\n');
					fprintf(fid,'\r\n');
					fprintf(fid,'\r\n');
					if DIST == 1;
						fprintf(fid,'DISTRIBUTION IS   NORMAL \r\n');
					elseif DIST == 2;
						fprintf(fid,'DISTRIBUTION IS   t5 \r\n');
					elseif DIST == 3;
						fprintf(fid,'DISTRIBUTION IS   t3 \r\n');
					elseif DIST == 4;
						fprintf(fid,'DISTRIBUTION IS   t2 \r\n');
					elseif DIST == 5;
						fprintf(fid,'DISTRIBUTION IS   Recentered Chi-Squared w/ 3 df \r\n');
					elseif DIST == 6;
						fprintf(fid,'DISTRIBUTION IS   Uniform \r\n');     
					end;     
					fprintf(fid,'\r\n');     
					fprintf(fid,'SAMPLE SIZE IS %4.0f\r\n',  N);     
					fprintf(fid,'\r\n');     
					fprintf(fid,'NUMBER OF MOMENT INEQUALITIES: P = %6.2f\r\n', P);     
					if VTYPE == -1 || VTYPE == 0 || VTYPE == 1;     	
						fprintf(fid,'VAR MATRIX IS TOEPLITZ WITH ELEMENTS = \r\n');
                        for i=1:size(RHOVEC,1);
                            fprintf(fid,'%6.4f', RHOVEC(i));
                            fprintf(fid,'\r\n');
                        end;    
					end;     
					fprintf(fid,'SUM OF CORR MATRIX ELEMENTS / P = %4.2f', AVGCORR);
					fprintf(fid,'\r\n');
					fprintf(fid,'MIN OVER SUBMATRICES OF C(OMEGA)*C/|C| = %4.2f', DELTA);
					fprintf(fid,'\r\n');
					fprintf(fid,'NUM OF REPS FOR CRIT VAL CALCULATIONS   =  %4.0f',  NUMR1*R1);
					fprintf(fid,'\r\n');
					fprintf(fid,'NUM OF REPS FOR REJ PROB CALCULATIONS   =  %4.0f',  SIMREPS);     
					fprintf(fid,'\r\n');
					
					% PRINT HEADING MATERIAL FOR SPECIFIC MU VALUE CONSIDERED.  
					fprintf(fid,'NUMBER OF MEAN VECTORS CONSIDERED = %2.0f\r\n', size(MU,1));     
					fprintf(fid,'MEAN VECTORS CONSIDERED ARE:\r\n');     
					for i=1:size(MU,1);        
						fprintf(fid,' %5.2f',[i,MU(i,:)]);        
						fprintf(fid,'\r\n');     
					end;
					fprintf(fid,'\r\n');  

					% NOW PRINT OUT THE RESULTS OF THE PROGRAM WHEN ETA VALUES ARE COMPUTED,
					% I.E., WHEN PROGTYPE<2.  
					if PROGTYPE<2;          
						fprintf(fid,'COMPUTED ETA VALUES ARE:  \r\n');          
						JPR = 1;          
						while JPR <= NUMTEST;            
							if TESTSEL( JPR )==1;                   
								fprintf(fid,'TEST NUM. %2.0f\r\n', JPR);                    
								if TESTMAT( JPR, 1) == 1;                            
									fprintf(fid,'SUM  TEST\r\n');                       
								elseif TESTMAT( JPR, 1) == 2.5;                            
									fprintf(fid,'ADJUSTED QLR TEST W/ EPSILON = .012\r\n');                   
								end;                    
								if TESTMAT( JPR, 3) == 0;                         
									fprintf(fid,'STD PA CV             ETA =  %6.4f\r\n', ETAVEC(JPR));                    
								elseif TESTMAT( JPR, 3) == 100;                         
									fprintf(fid,'BOOTSTRAP PA CV       ETA =  %6.4f\r\n', ETAVEC(JPR));                    
								elseif TESTMAT( JPR, 3) == 1;                        
									fprintf(fid,'PHI1, t TEST CV; KAPPA =   %6.4f', TESTMAT( JPR, 5));                        
									fprintf(fid,'                      ETA = %6.4f\r\n', ETAVEC(JPR));                    
								elseif TESTMAT( JPR, 3) == 101;                         
									fprintf(fid,'BOOTSTRAP PHI1, t TEST CV; KAPPA = %6.4f', TESTMAT( JPR, 5));                         
									fprintf(fid,'     ETA = ', ETAVEC(JPR));                    
								elseif TESTMAT( JPR, 3) == 11;                         
									[KAPPA, ETAAUTO1] = AUTOMAT(DELTA,P);                                     
									fprintf(fid,'PHI1, t TEST CV; AUTOMATIC KAPPA = %6.4f', KAPPA);                         
									fprintf(fid,'     ETAAUTO = %6.4f', ETAAUTO1);                                                
									fprintf(fid,'     ETA = %6.4f\r\n', ETAVEC(JPR));                    
								elseif TESTMAT( JPR, 3) == 1011;                         
									[KAPPA, ETAAUTO1] = AUTOMAT(DELTA,P);                         
									fprintf(fid,'BOOTSTRAP PHI1, t TEST CV; AUTOMATIC KAPPA = %6.4f', KAPPA);                         
									fprintf(fid,'     ETAAUTO = %6.4f', ETAAUTO1);                                                 
									fprintf(fid,'     ETA = %6.4f\r\n', ETAVEC(JPR));                    
								end;                    
								fprintf(fid,'ETA VALUE FOR EACH MU VECTOR:');
								fprintf(fid,' %6.4f', ETAMAT( JPR, : ));
								fprintf(fid,'\r\n'); 
								fprintf(fid,'REJ PROBS WHEN ETA = 0:              ');
								fprintf(fid,' %6.4f',REJMAT( JPR, :));
								fprintf(fid,'\r\n'); 
								fprintf(fid,'MAX REJ PROB WHEN ETA = 0:         ');
								fprintf(fid,' %6.4f',max( REJMAT( JPR, :) ));
								fprintf(fid,'\r\n');
								fprintf(fid,'\r\n');  
							end;              
							JPR = JPR +1;
						end;      
					end;

					% THIS IS THE START OF THE PRINT STATEMENTS THAT ARE USED JUST FOR THE POWER
					% RESULTS, I.E., JUST for THE CASE WHERE PROGTYPE = 2.  
					% PRINT OUT THE RESULTS FOR TEST STATISTICS AND MU VALUES GROUPED BY TEST.  
					fprintf(fid,'\r\n');     
					fprintf(fid,'REJ PROBS: GROUPED BY TEST\r\n');     
					fprintf(fid,'\r\n');     
					G =1;     
					while G <= NUMTEST;          
						if TESTSEL(G) == 1;                    
							fprintf(fid,'TEST NUM. %2.0f\r\n', G);                     
							if TESTMAT( G, 1) == 1;                            
								fprintf(fid,'SUM  TEST');                            
								fprintf(fid,'    ETA = %6.5f\r\n',ETAVEC(G));                       
							elseif TESTMAT( G, 1) == 2.5;                            
								fprintf(fid,'ADJUSTED QLR TEST W/ EPSILON = .012');                            
								fprintf(fid,'    ETA = %6.5f\r\n',ETAVEC(G));                    
							end;                    
							if TESTMAT( G, 3) == 0;                           
								fprintf(fid,'STD PA CV\r\n') ;                       
							elseif TESTMAT( G, 3) == 100;                           
								fprintf(fid,'BOOTSTRAP PA CV\r\n') ;                       
							elseif TESTMAT( G, 3) == 1;                           
								fprintf(fid,'PHI1, t TEST CV;             KAPPA = %3.2f\r\n', TESTMAT( G, 5));                       
							elseif TESTMAT( G, 3) == 101;                           
								fprintf(fid,'BOOTSTRAP PHI1, t TEST CV;       KAPPA = %3.2f\r\n', TESTMAT( G, 5));                       
							elseif TESTMAT( G, 3) == 11;                           
								[KAPPA, ETAAUTO1] = AUTOMAT(DELTA,P);                           
								fprintf(fid,'PHI1, t TEST CV; AUTOMATIC KAPPA = %3.2f\r\n',  KAPPA);                           
								fprintf(fid,'  ETAAUTO = %3.4f\r\n',  ETAAUTO1);                       
							elseif TESTMAT( G, 3) == 1011;                           
								[KAPPA, ETAAUTO1] = AUTOMAT(DELTA,P);                          
								fprintf(fid,'BOOTSTRAP PHI1, t TEST CV; AUTOMATIC KAPPA = %3.2f\r\n',  KAPPA);                           
								fprintf(fid,'  ETAAUTO =  %3.4f\r\n',  ETAAUTO1);                    
							end;                                    
							J = 1;               
							while J <= size(MU,1);                     
								fprintf(fid,'MU %4.0f', J);                     
								fprintf(fid,'   AVG CV = %4.2f',  AVGQUANT(G, J));                     
								fprintf(fid,'   SD CV = %4.2f', SDQUANT(G, J));                     
								fprintf(fid,'   REJ PROB =  %4.4f', REJMAT(G, J));
								fprintf(fid,'\r\n');
								J = J + 1;               
							end;               
							fprintf(fid,'\r\n');          
						end;
						G = G + 1;     
					end;
					
					%   PRINT OUT MATRIX OF RESULTS WITH ROWS GIVEN BY REJ PROBS OF TESTS AND COLUMNS 
					%   GIVEN BY  MU VALUES.  
					if PROGTYPE==2;
						fprintf(fid,'REJ PROBS: GROUPED BY MU VECTOR\r\n');                          
						fprintf(fid,'\r\n');                           
						B = 1;                          
						while B <= 20;                           					       
							J = 5*(B-1)+1;                         
							while J <= min([size(MU,1);(5*B)]);
                                fprintf(fid,'     ');
								if B <= 2;                                
									fprintf(fid,'       MU %2.0f', J);                                 
								else                                
									fprintf(fid,'      MU %2.0f', J);                           
								end;                          
								J = J + 1;               
							end;                     
							if (5*(B-1)+1)<=size(MU,1);                          
								fprintf(fid,'\r\n');                       
							end;              
							G = 1;                
							while G <= NUMTEST && (5*(B-1)+1)<=size(MU,1);                         
								if TESTSEL(G) == 1;                        
									fprintf(fid,'TEST %2.0f', G);                           
									fprintf(fid,':');
                                    fprintf(fid,'   ');
									J =5*(B-1)+1;                              
									while J <= min([size(MU,1);(5*B)]);                               
										fprintf(fid,'       %5.4f', REJMAT(G, J));                               
										J = J + 1;                             
									end;                             
									fprintf(fid,'\r\n');               
								end;                          
								if G==4;                            
									fprintf(fid,'\r\n');                       
								end;                      
								G = G + 1;               
							end;             
							if (5*(B-1)+1)<=size(MU,1);                      
								fprintf(fid,'\r\n');                      
							end;                     
							B = B + 1;               
						end;                
						fprintf(fid,'\r\n');

						% PRINT AVG POWER OVER ALL MU VALUES AND SUBSETS OF MU VALUES.  
						fprintf(fid,'AVG REJ PROBS: \r\n');  
						if P==2;                   
							fprintf(fid,'            ALL        1      VIOLN     2      \r\n');                      
							fprintf(fid,'            MU.      VIOLN.   & 0S.  VIOLNS\r\n');               
						elseif P==4;                     
							fprintf(fid,'            ALL     2        1    VIOLNS  VIOLNS\r\n');                    
							fprintf(fid,'            MU.   VIOLNS.  VIOLN.  & 0s. & INFS\r\n');                       
						elseif P>=7;                    
							fprintf(fid,'            ALL     2        4      1     VIOLNS  VIOLNS\r\n');                    
							fprintf(fid,'            MU.   VIOLNS. VIOLNS. VIOLN.  & 0s.  & INFS\r\n');                             
						end;                
						G = 1;                 
						while G <= NUMTEST;                    
							if TESTSEL(G) == 1;                                
								if P==2;                             
									fprintf(fid,'TEST %2.0f', G);                             
									fprintf(fid,':');                              
									fprintf(fid,'  %5.3f', mean(REJMAT(G, :)));
                                    fprintf(fid,'       %5.3f', mean(REJMAT(G, 2:6))); 
									fprintf(fid,'       %5.3f', mean(REJMAT(G, 1)));                                                            
									fprintf(fid,'       %5.3f\r\n', mean(REJMAT(G, 7)));                          
								elseif P==4;                           
									fprintf(fid,'TEST %2.0f', G);                                
									fprintf(fid,':');                                   
									fprintf(fid,'  %5.3f', mean(REJMAT(G, :)));                          
									fprintf(fid,'       %5.3f', mean(REJMAT(G, 1:9)));                    
									fprintf(fid,'       %5.3f', mean(REJMAT(G, 10:18)));                        
									fprintf(fid,'       %5.3f', mean(REJMAT(G, 19:20)));                                         
									fprintf(fid,'       %5.3f\r\n', mean(REJMAT(G, 21:24)));                                
								elseif P==10;                                         
									fprintf(fid,'TEST %2.0f', G);                                         
									fprintf(fid,':');                                         
									fprintf(fid,'  %5.3f', mean(REJMAT(G, :)));                                         
									fprintf(fid,'       %5.3f', mean(REJMAT(G, 1:9)));
                                    fprintf(fid,'       %5.3f', mean(REJMAT(G, 10:18))); 
									fprintf(fid,'       %5.3f', mean(REJMAT(G, 19:27)));                                         
									fprintf(fid,'       %5.3f', mean(REJMAT(G, 28:30)));                                         
									fprintf(fid,'       %5.3f\r\n', mean(REJMAT(G, 31:40)));                                     
								end;                                 
							end;                                 
							G = G + 1;                             
						end;                         
						fprintf(fid,'\r\n');

						% PRINT HEADING MATERIAL THAT STATES WHICH TESTS ARE CONSIDERED.  
						fprintf(fid,'NUMBER OF MEAN VECTORS CONSIDERED = %2.0f\r\n', size(MU,1));                          
						fprintf(fid,'MEAN VECTORS CONSIDERED ARE:\r\n');                       
						for i=1:size(MU,1);                              
							fprintf(fid,'  %5.2f',[i,MU(i,:)]);                                    
							fprintf(fid,'\r\n');                             
						end;                             
						JPR = 1;                                
						while JPR <= NUMTEST;            
							if TESTSEL( JPR ) ==1;                 
								fprintf(fid,'TEST NUM. %2.0f\r\n', JPR);                  
								if TESTMAT( JPR, 1) == 1;                            
									fprintf(fid,'SUM  TEST ');                            
									fprintf(fid,'    ETA = %6.5f\r\n',ETAVEC(JPR));                 
								elseif TESTMAT( JPR, 1) == 2.5;                            
									fprintf(fid,'ADJUSTED QLR TEST W/ EPSILON = .012');                            
									fprintf(fid,'    ETA = %6.5f\r\n',ETAVEC(JPR));                 
								end;                                                      
								if TESTMAT( JPR, 3) == 0;                       
									fprintf(fid,'STD PA CV\r\n') ;                  
								elseif TESTMAT( JPR, 3) == 100;                       
									fprintf(fid,'BOOTSTRAP PA CV\r\n') ;                  
								elseif TESTMAT( JPR, 3) == 1;                       
									fprintf(fid,'PHI1, t TEST CV;             KAPPA = %3.2f\r\n', TESTMAT( JPR, 5));                                                     
								elseif TESTMAT( JPR, 3) == 101;                       
									fprintf(fid,'BOOTSTRAP PHI1, t TEST CV; KAPPA = %3.2f\r\n', TESTMAT( JPR, 5));                  
								elseif TESTMAT( JPR, 3) == 11;                       
									[KAPPA, ETAAUTO1] = AUTOMAT(DELTA,P);                       
									fprintf(fid,'PHI1, t TEST CV; AUTOMATIC KAPPA = %3.2f',  KAPPA);                       
									fprintf(fid,'  ETAAUTO = %3.4f\r\n' ,  ETAAUTO1);                    
								elseif TESTMAT( JPR, 3) == 1011;                      
									[KAPPA, ETAAUTO1] = AUTOMAT(DELTA,P);                       
									fprintf(fid,'BOOTSTRAP PHI1, t TEST CV; AUTOMATIC KAPPA = %3.2f',  KAPPA);                       
									fprintf(fid,'  ETAAUTO = %3.4f\r\n' ,  ETAAUTO1);                                           
								end;                  
								fprintf(fid,'\r\n');            
							end;            
							JPR = JPR +1;        
						end;  
					end;
					% THIS IS THE END OF THE PRINT STATEMENTS THAT ARE USED JUST FOR THE POWER
					% RESULTS, I.E., JUST for THE CASE WHERE PROGTYPE = 2.  

					% FINAL PRINT STATEMENTS.  
					fprintf(fid,'NUMBER OF MOMENT INEQUALITIES: P = %6.2f\r\n', P);     
					if VTYPE == -1 || VTYPE == 0 || VTYPE == 1;              
						fprintf(fid,'VAR MATRIX IS TOEPLITZ WITH ELEMENTS = \r\n');             
						fprintf(fid,'%6.2f',RHOVEC');
                        fprintf(fid,'\r\n'); 
					end;     
					fprintf(fid,'SUM OF CORR MATRIX ELEMENTS / P = %6.2f\r\n', AVGCORR);     
					fprintf(fid,'MIN OVER SUBMATRICES OF C(OMEGA)*C/|C| = %6.2f\r\n', DELTA);
					fprintf(fid,'NUM OF REPS FOR CRIT VAL CALCULATIONS   =  %6.0f\r\n',  NUMR1*R1);     
					fprintf(fid,'NUM OF REPS FOR REJ PROB CALCULATIONS   =  %6.0f\r\n',  SIMREPS);     
					fprintf(fid,'\r\n');     
					fprintf(fid,'                              FINITE-SAMPLE RESULTS\r\n');     
					fprintf(fid,'SAMPLE SIZE N = %4.0f\r\n', N);     
					if DIST == 1;            
						fprintf(fid,'DISTRIBUTION IS   NORMAL\r\n');         
					elseif DIST == 2;         
						fprintf(fid,'DISTRIBUTION IS   t5\r\n');         
					elseif DIST == 3;         
						fprintf(fid,'DISTRIBUTION IS   t3\r\n');         
					elseif DIST == 4;         
						fprintf(fid,'DISTRIBUTION IS   t2\r\n');         
					elseif DIST == 5;         
						fprintf(fid,'DISTRIBUTION IS   Recentered Chi-Squared w/ 3 df\r\n');         
					elseif DIST == 6;         
						fprintf(fid,'DISTRIBUTION IS   Uniform\r\n');     
					end;   
					T1 = clock;   
					ELAPTIME = toc(T0);     
					fprintf(fid,'\r\n');        
					fprintf(fid, 'TIME IN MINUTES FOR ALL CASES TO RUN IS %6.3f\r\n', ELAPTIME/60);        
					fprintf(fid, 'TIME IN HOURS FOR CASES TO RUN IS       %6.3f\r\n', ELAPTIME/(60^2));        
					fprintf(fid,'\r\n');     
					PROGTYPE = PROGTYPE + 1;     
				end;
				% THIS IS THE END OF THE LOOP OVER PROGTYPE.  

				fprintf(fid,'\r\n');   
				fprintf(fid,'**********************************************************************************************************');   
				fprintf(fid,'**********************************************************************************************************');

				% THE NEXT LINES END THE DO LOOPS OVER P, N, DIST, AND V.  
				VTYPE = VTYPE + 1;
			end;
			
			DIST = DIST + 1;
		end;
		
		if N == 100;
			N = 250;
		elseif N == 250;
			N = 500;
		elseif N == 500;
			N = 1000;
		end;
	end;    
	
	if P == 2        
		P = 4;            
	elseif P == 4;        
		P = 10;            
	elseif P == 10;        
	P = 15;          
	end;       
end;
%   END OF DO LOOPS OVER N, P, DIST, AND V.  
fclose('all');                        
					