%/********************************************************************************************/
%{    RE ANDREWS AND BARWICK (2012) PAPER:
      THE FOLLOWING PROCEDURE IS USED BY rmsprg_final.m / rmsprg_fs_short_final.m AND COMPUTES 
      KAPPA AND ETA-AUTO BASED ON A GIVEN VALUE OF DELTA
      AND A RULE (THAT IS PROGRAMMED INTO THE CODE) FOR HOW KAPPA and ETA-AUTO SHOULD DEPEND
      ON DELTA.  DELTA IS A MEASURE OF HOW MUCH CORRELATION IS IN THE CORRELATION MATRIX 
      OMEGA, WHICH CORRESPONDS TO THE VARIANCE MATRIX V.  

      THE FOLLOWING KAPPA VALUES WERE DETERMINED BY MAXIMIZING AVG POWER OVER KAPPA
      for THE CASE OF P = 2 USING PROGRAM kappaprg. DONE ON JAN 21/11. THE KAPPA VALUES 
      for DELTA <=-.85 ARE NOT THE ONES THAT YIELD MAXIMUM AVG POWER for P=2. THEY HAVE 
      BEEN TAKEN TO BE LARGER THAN THOSE VALUES BECAUSE THIS IMPROVES SIZE PROPERTIES for 
      P>2, ONLY SACRIFICES A LITTLE POWER for P=2, and SACRIFICES NO POWER for P>2. THE
      RESULTS for p=2 WERE COMPUTED USING THIS PROGRAM, kappaprg_final, WITH 200,000 
      SIMULATION REPETITIONS BY THE METHOD DESCRIBED AT THE BEGINNING OF THIS PROGRAM
      THE RESULTS for p>=3 WERE COMPUTED USING PROGRAMS etaprg1_final and etaprg2_final
      WITH 40,000 SIMULATION REPETITIONS.  */
%}

function[KAPPA, ETAAUTO] = AUTOMAT(DELTA,P)

      if DELTA < -.975;
            KAPPA = 2.9; ETAAUTO = .025;
         elseif DELTA >= -.975 && DELTA < -.95;
            KAPPA = 2.9; ETAAUTO = .026;
         elseif DELTA >= -.95 && DELTA < -.90;
            KAPPA = 2.9; ETAAUTO = .021;
         elseif DELTA >= -.90 && DELTA < -.85;
            KAPPA = 2.8; ETAAUTO = .027;
         elseif DELTA >= -.85 && DELTA < -.80;
            KAPPA = 2.7; ETAAUTO = .062;
         elseif DELTA >= -.80 && DELTA < -.75;
            KAPPA = 2.6; ETAAUTO = .104;    
         elseif DELTA >= -.75 && DELTA < -.70;
            KAPPA = 2.6; ETAAUTO = .103;
         elseif DELTA >= -.70 && DELTA < -.65;
            KAPPA = 2.5; ETAAUTO = .131;
         elseif DELTA >= -.65 && DELTA < -.60;
            KAPPA = 2.5; ETAAUTO = .122;
         elseif DELTA >= -.60 && DELTA < -.55;
            KAPPA = 2.5; ETAAUTO = .113;
         elseif DELTA >= -.55 && DELTA < -.50;
            KAPPA = 2.5; ETAAUTO = .104;
         elseif DELTA >= -.50 && DELTA < -.45;
            KAPPA = 2.4; ETAAUTO = .124;
         elseif DELTA >= -.45 && DELTA < -.40;
            KAPPA = 2.2; ETAAUTO = .158;
         elseif DELTA >= -.40 && DELTA < -.35;
            KAPPA = 2.2; ETAAUTO = .133;
         elseif DELTA >= -.35 && DELTA < -.30;
            KAPPA = 2.1; ETAAUTO = .138;
         elseif DELTA >= -.30 && DELTA < -.25;
            KAPPA = 2.1; ETAAUTO = .111;
         elseif DELTA >= -.25 && DELTA < -.20;
            KAPPA = 2.1; ETAAUTO = .082;
         elseif DELTA >= -.20 && DELTA < -.15;
            KAPPA = 2.0; ETAAUTO = .083;
         elseif DELTA >= -.15 && DELTA < -.10;
            KAPPA = 2.0; ETAAUTO = .074;
         elseif DELTA >= -.10 && DELTA < -.05;
            KAPPA = 1.9; ETAAUTO = .082;
         elseif DELTA >= -.05 && DELTA < 0.00;
            KAPPA = 1.8; ETAAUTO = .075;
         elseif DELTA >= 0.00 && DELTA < 0.05;
            KAPPA = 1.5; ETAAUTO = .114;
         elseif DELTA >= 0.05 && DELTA < 0.10;
            KAPPA = 1.4; ETAAUTO = .112;
         elseif DELTA >= 0.10 && DELTA < 0.15;
            KAPPA = 1.4; ETAAUTO = .083;
         elseif DELTA >= 0.15 && DELTA < 0.20;
            KAPPA = 1.3; ETAAUTO = .089;
         elseif DELTA >= 0.20 && DELTA < 0.25;
            KAPPA = 1.3; ETAAUTO = .058;
         elseif DELTA >= 0.25 && DELTA < 0.30;
            KAPPA = 1.2; ETAAUTO = .055;
         elseif DELTA >= 0.30 && DELTA < 0.35;
            KAPPA = 1.1; ETAAUTO = .044;
         elseif DELTA >= 0.35 && DELTA < 0.40;
            KAPPA = 1.0; ETAAUTO = .040;
         elseif DELTA >= 0.40 && DELTA < 0.45;
            KAPPA = 0.8; ETAAUTO = .051;
         elseif DELTA >= 0.45 && DELTA < 0.50;
            KAPPA = 0.8; ETAAUTO = .023;
         elseif DELTA >= 0.50 && DELTA < 0.55;
            KAPPA = 0.6; ETAAUTO = .033;
         elseif DELTA >= 0.55 && DELTA < 0.60;
            KAPPA = 0.6; ETAAUTO = .013;
         elseif DELTA >= 0.60 && DELTA < 0.65;
            KAPPA = 0.4; ETAAUTO = .016;
         elseif DELTA >= 0.65 && DELTA < 0.70;
            KAPPA = 0.4; ETAAUTO = .000;
         elseif DELTA >= 0.70 && DELTA < 0.75;
            KAPPA = 0.2; ETAAUTO = .003;
         elseif DELTA >= 0.75 && DELTA < 0.80;
            KAPPA = 0.0; ETAAUTO = .002;
         elseif DELTA >= 0.80 && DELTA < 0.85;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.85 && DELTA < 0.90;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.90 && DELTA < 0.95;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.95 && DELTA < 0.975;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.975 && DELTA < 0.99;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.99;       
            KAPPA = 0.0; ETAAUTO = .000;
      end;

%    THE AUTOETA VALUES ABOVE HAVE BEEN DETERMINED FOR P==2. FOR P >= 3, WE HAVE TO 
%    INCREASE THEM ALL BY THE AMOUNT INDICATED. 
          if P == 3;
            ETAAUTO = ETAAUTO + .15;
         elseif P == 4;
            ETAAUTO = ETAAUTO + .17;
         elseif P == 5;
            ETAAUTO = ETAAUTO + .24;
         elseif P == 6;
            ETAAUTO = ETAAUTO + .31;
         elseif P == 7;
            ETAAUTO = ETAAUTO + .33;
         elseif P == 8;
            ETAAUTO = ETAAUTO + .37;
         elseif P == 9;
            ETAAUTO = ETAAUTO + .45;
         elseif P == 10;
            ETAAUTO = ETAAUTO + .50;
         end;
